#include <vector>
#include <string>
#include <fstream>
#include <iostream>

#include "Stock.hpp"

int main(int argc, char * argv[]) {

    /* Read in command line arguments */

    /* Import prices to std::vector<double> */

    /* Call the Stock class constructor */

    /* Perform reqired calculations */

    /* Write out to results.txt */


}

